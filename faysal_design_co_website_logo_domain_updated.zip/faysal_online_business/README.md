# Faysal Design Co. — Customer Website + Separate Admin Panel

This is a deployable Node.js + Express + PostgreSQL project. The public customer website is `/`; the separate admin login is `/admin.html`. The public website contains no admin link or admin dashboard UI.

## Customer website features
- Responsive, animated landing page with service cards, portfolio concepts, product catalogue and order form.
- Live products loaded from PostgreSQL-backed API; search and category filtering.
- Customers can select multiple products and submit an order request.
- Orders are stored server-side and appear in the separate admin dashboard.
- Smooth reveal animations, animated hero/brand, product hover states, mobile-friendly layout and reduced-motion support.

## Admin features
- Separate login page at `/admin.html`; login is verified server-side.
- Product create/edit/hide/delete and image URL fields.
- View orders, update order status, delete orders, export CSV.
- Edit business name, logo, tagline, hero copy, contact info, accent colour and portfolio text.
- Change admin password.

## Local setup
Requirements: Node.js 20+ and a PostgreSQL database.
1. Extract the ZIP.
2. Run `npm install`.
3. Set environment variables before running: `DATABASE_URL`, `SESSION_SECRET` (32+ random characters), `ADMIN_EMAIL`, `ADMIN_PASSWORD` (12+ characters), and `NODE_ENV=development` for local testing.
4. Run `npm start`.
5. Open `http://localhost:3000` for customers and `http://localhost:3000/admin.html` for admin.

The app requires PostgreSQL and will not work as a static HTML file opened by double-clicking.

## Deploy
- Push the project to a private Git repository.
- Provision a managed PostgreSQL database.
- Create a Node Web Service on Render or another Node host; build `npm install`, start `npm start`, health path `/api/health`.
- Set `NODE_ENV=production`, `DATABASE_URL`, `SESSION_SECRET` (random 32+ characters), `ADMIN_EMAIL`, and `ADMIN_PASSWORD` (12+ characters) in the host's environment settings. Never put secrets in the code or send them in chat.
- After deploying, visit the public root URL. Keep `/admin.html` private to the owner; it requires a valid login.

## Notes
- This package is code, not a live deployed website. It must be hosted and connected to PostgreSQL.
- Orders are design requests, not payments. Confirm final quote and payment with the customer.
- Logo and product image fields accept public HTTPS URLs; local file uploads need object storage integration.
- Use HTTPS, managed database backups, and strong unique credentials in production.


## Branding and custom domain
The supplied Faysal Design Co. logo is included at `public/faysal-logo.png` and used by the customer site and admin panel. Suggested domain: `faysaldesignco.in`; domain availability and registration are separate and are not included. After deploying, add the purchased domain under your hosting provider’s Custom Domains settings and follow its DNS instructions.
