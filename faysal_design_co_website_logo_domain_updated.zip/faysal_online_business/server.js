'use strict';
const express = require('express');
const helmet = require('helmet');
const session = require('express-session');
const PgSession = require('connect-pg-simple')(session);
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();
const isProduction = process.env.NODE_ENV === 'production';
const port = Number(process.env.PORT || 3000);
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_SSL === 'false' ? false : (isProduction ? { rejectUnauthorized: false } : false) });

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: false, limit: '100kb' }));
app.use(session({
  store: new PgSession({ pool, tableName: 'user_sessions', createTableIfMissing: true }),
  name: 'faysal.sid',
  secret: process.env.SESSION_SECRET || (isProduction ? '' : 'local-development-only-change-me'),
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, secure: isProduction, sameSite: 'lax', maxAge: 1000 * 60 * 60 * 8 }
}));

const defaultProducts = [
  ['Banner Design','Print Design',300,'Shop, school, club and event banners.','',true],
  ['Logo Design','Branding',350,'A clean identity concept for your business.','',true],
  ['Poster Design','Print Design',250,'Promotional posters for events and offers.','',true],
  ['ID Card Design','Cards & Stationery',200,'Professional identity cards for school, club or office.','',true],
  ['ID Card Ribbon Design','Cards & Stationery',250,'Matching lanyard artwork with logo and brand colours.','',true],
  ['Bill Book Design','Cards & Stationery',300,'Invoice, receipt pad and bill book layout.','',true],
  ['Social Media Template','Digital Design',150,'Reusable promotional social media template.','',true],
  ['Visiting Card Design','Cards & Stationery',200,'Business card design matching your brand.','',true]
];
const defaultSettings = {
  name: 'Faysal Design Co.', logo: 'F', tagline: 'CREATIVE DESIGN STUDIO',
  heroTitle: 'Your Vision. | Our Design.',
  heroText: 'Creative and professional graphic design for shops, schools, clubs, events and growing businesses. Tell us what you need, share your ideas, and request a custom design.',
  email: '', whatsapp: '', phone: '', color: '#ffc928', logoImageUrl: '/faysal-logo.png',
  portfolio: []
};

async function initDb() {
  if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required. Set up a PostgreSQL database first.');
  if (isProduction && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32)) throw new Error('SESSION_SECRET must be set to a random secret of at least 32 characters in production.');
  await pool.query(`CREATE TABLE IF NOT EXISTS admins (id SERIAL PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
    CREATE TABLE IF NOT EXISTS products (id SERIAL PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL, price NUMERIC(10,2) NOT NULL DEFAULT 0, description TEXT NOT NULL DEFAULT '', image_url TEXT NOT NULL DEFAULT '', visible BOOLEAN NOT NULL DEFAULT TRUE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
    CREATE TABLE IF NOT EXISTS orders (id BIGSERIAL PRIMARY KEY, customer_name TEXT NOT NULL, phone TEXT NOT NULL, design_type TEXT NOT NULL, budget TEXT NOT NULL DEFAULT '', quantity INTEGER NOT NULL DEFAULT 1, size TEXT NOT NULL DEFAULT '', deadline TEXT NOT NULL DEFAULT '', style TEXT NOT NULL DEFAULT '', details TEXT NOT NULL, reference_url TEXT NOT NULL DEFAULT '', items JSONB NOT NULL DEFAULT '[]'::jsonb, status TEXT NOT NULL DEFAULT 'Pending', created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
    CREATE TABLE IF NOT EXISTS site_settings (id INTEGER PRIMARY KEY CHECK (id=1), settings JSONB NOT NULL, updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW());`);
  const adminEmail = String(process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  const adminPassword = String(process.env.ADMIN_PASSWORD || '');
  if (adminEmail && adminPassword.length >= 12) {
    const existing = await pool.query('SELECT id FROM admins WHERE email=$1', [adminEmail]);
    if (!existing.rowCount) {
      const hash = await bcrypt.hash(adminPassword, 12);
      await pool.query('INSERT INTO admins(email,password_hash) VALUES($1,$2)', [adminEmail, hash]);
      console.log(`Initial admin account created for ${adminEmail}`);
    } else if (process.env.RESET_ADMIN_PASSWORD === 'true') {
      const hash = await bcrypt.hash(adminPassword, 12);
      await pool.query('UPDATE admins SET password_hash=$2 WHERE email=$1', [adminEmail, hash]);
      console.log(`Admin password reset for ${adminEmail}`);
    }
  }
  const count = await pool.query('SELECT COUNT(*)::int AS n FROM products');
  if (count.rows[0].n === 0) for (const p of defaultProducts) await pool.query('INSERT INTO products(name,category,price,description,image_url,visible) VALUES($1,$2,$3,$4,$5,$6)', p);
  await pool.query('INSERT INTO site_settings(id,settings) VALUES(1,$1::jsonb) ON CONFLICT(id) DO NOTHING', [JSON.stringify(defaultSettings)]);
}

function requireAdmin(req,res,next){ if(req.session && req.session.adminId) return next(); return res.status(401).json({error:'Please sign in as an administrator.'}); }
function cleanString(value,max=1000){ return String(value ?? '').trim().slice(0,max); }
function validHttpUrl(value){ if(!value) return ''; try { const u=new URL(value); return ['http:','https:'].includes(u.protocol) ? u.toString() : ''; } catch { return ''; } }
const loginLimiter = rateLimit({ windowMs: 15*60*1000, limit: 8, standardHeaders: true, legacyHeaders: false, message: {error:'Too many login attempts. Wait 15 minutes and try again.'} });
const orderLimiter = rateLimit({ windowMs: 60*60*1000, limit: 20, standardHeaders: true, legacyHeaders: false, message: {error:'Too many order requests. Please try again later.'} });

app.get('/api/health', async (_req,res)=>{ try { await pool.query('SELECT 1'); res.json({ok:true}); } catch { res.status(503).json({ok:false}); } });
app.get('/api/settings', async (_req,res)=>{ try { const r=await pool.query('SELECT settings FROM site_settings WHERE id=1'); res.json({settings:r.rows[0]?.settings || defaultSettings}); } catch(e){ console.error(e); res.status(500).json({error:'Could not load website settings.'}); } });
app.get('/api/products', async (_req,res)=>{ try { const r=await pool.query('SELECT id,name,category,price,description,image_url AS "imageUrl",visible FROM products WHERE visible=TRUE ORDER BY created_at DESC,id DESC'); res.json({products:r.rows}); } catch(e){ console.error(e); res.status(500).json({error:'Could not load products.'}); } });
app.post('/api/orders', orderLimiter, async (req,res)=>{
  const b=req.body||{}; const name=cleanString(b.name,100), phone=cleanString(b.phone,40), type=cleanString(b.type,100), details=cleanString(b.details,4000);
  if(name.length<2 || phone.length<5 || !type || details.length<3) return res.status(400).json({error:'Please provide your name, phone, design type and design details.'});
  const quantity=Math.max(1,Math.min(5000,parseInt(b.quantity,10)||1));
  try { const r=await pool.query(`INSERT INTO orders(customer_name,phone,design_type,budget,quantity,size,deadline,style,details,reference_url,items) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11::jsonb) RETURNING id,created_at`,[name,phone,type,cleanString(b.budget,80),quantity,cleanString(b.size,120),cleanString(b.deadline,30),cleanString(b.style,300),details,validHttpUrl(cleanString(b.reference,500)),JSON.stringify(Array.isArray(b.items)?b.items.slice(0,30):[])]); res.status(201).json({ok:true,order:{id:`FD-${String(r.rows[0].id).padStart(6,'0')}`,createdAt:r.rows[0].created_at}}); } catch(e){ console.error(e); res.status(500).json({error:'Could not save your order. Please try again.'}); }
});
app.post('/api/admin/login',loginLimiter,async(req,res)=>{
  const email=cleanString(req.body?.email,200).toLowerCase(), password=String(req.body?.password||'');
  if(!email||!password) return res.status(400).json({error:'Email and password are required.'});
  try { const r=await pool.query('SELECT id,email,password_hash FROM admins WHERE email=$1',[email]); const admin=r.rows[0]; if(!admin || !(await bcrypt.compare(password,admin.password_hash))) return res.status(401).json({error:'Email or password is incorrect.'});
    await new Promise((resolve,reject)=>req.session.regenerate(err=>err?reject(err):resolve())); req.session.adminId=admin.id; req.session.adminEmail=admin.email;
    await new Promise((resolve,reject)=>req.session.save(err=>err?reject(err):resolve())); res.json({ok:true,email:admin.email});
  } catch(e){ console.error(e); res.status(500).json({error:'Login service is temporarily unavailable.'}); }
});
app.post('/api/admin/logout',(req,res)=>{req.session.destroy(()=>{res.clearCookie('faysal.sid',{httpOnly:true,sameSite:'lax',secure:isProduction});res.json({ok:true});});});
app.get('/api/admin/me',requireAdmin,(req,res)=>res.json({ok:true,email:req.session.adminEmail}));
app.post('/api/admin/password',requireAdmin,async(req,res)=>{const currentPassword=String(req.body?.currentPassword||''),newPassword=String(req.body?.newPassword||'');if(newPassword.length<12)return res.status(400).json({error:'New password must be at least 12 characters.'});try{const r=await pool.query('SELECT password_hash FROM admins WHERE id=$1',[req.session.adminId]);if(!r.rowCount||!(await bcrypt.compare(currentPassword,r.rows[0].password_hash)))return res.status(400).json({error:'Current password is incorrect.'});const hash=await bcrypt.hash(newPassword,12);await pool.query('UPDATE admins SET password_hash=$1 WHERE id=$2',[hash,req.session.adminId]);res.json({ok:true});}catch(e){console.error(e);res.status(500).json({error:'Could not change password.'});}});
app.get('/api/admin/products',requireAdmin,async(_req,res)=>{try{const r=await pool.query('SELECT id,name,category,price,description,image_url AS "imageUrl",visible,created_at FROM products ORDER BY created_at DESC,id DESC');res.json({products:r.rows});}catch(e){console.error(e);res.status(500).json({error:'Could not load products.'});}});
app.post('/api/admin/products',requireAdmin,async(req,res)=>{const b=req.body||{},name=cleanString(b.name,100),category=cleanString(b.category,80),description=cleanString(b.description,500),price=Number(b.price);if(!name||!category||!description||!Number.isFinite(price)||price<0)return res.status(400).json({error:'Enter a product name, category, valid price and description.'});try{const r=await pool.query('INSERT INTO products(name,category,price,description,image_url,visible) VALUES($1,$2,$3,$4,$5,$6) RETURNING *',[name,category,price,description,validHttpUrl(cleanString(b.imageUrl,1000)),b.visible!==false]);res.status(201).json({product:r.rows[0]});}catch(e){console.error(e);res.status(500).json({error:'Could not create product.'});}});
app.put('/api/admin/products/:id',requireAdmin,async(req,res)=>{const b=req.body||{},id=Number(req.params.id),name=cleanString(b.name,100),category=cleanString(b.category,80),description=cleanString(b.description,500),price=Number(b.price);if(!Number.isInteger(id)||!name||!category||!description||!Number.isFinite(price)||price<0)return res.status(400).json({error:'Invalid product information.'});try{const r=await pool.query('UPDATE products SET name=$1,category=$2,price=$3,description=$4,image_url=$5,visible=$6,updated_at=NOW() WHERE id=$7 RETURNING *',[name,category,price,description,validHttpUrl(cleanString(b.imageUrl,1000)),b.visible!==false,id]);if(!r.rowCount)return res.status(404).json({error:'Product not found.'});res.json({product:r.rows[0]});}catch(e){console.error(e);res.status(500).json({error:'Could not update product.'});}});
app.delete('/api/admin/products/:id',requireAdmin,async(req,res)=>{try{const r=await pool.query('DELETE FROM products WHERE id=$1',[Number(req.params.id)]);if(!r.rowCount)return res.status(404).json({error:'Product not found.'});res.json({ok:true});}catch(e){console.error(e);res.status(500).json({error:'Could not delete product.'});}});
app.get('/api/admin/orders',requireAdmin,async(_req,res)=>{try{const r=await pool.query('SELECT id,customer_name AS name,phone,design_type AS type,budget,quantity,size,deadline,style,details,reference_url AS reference,items,status,created_at AS "createdAt" FROM orders ORDER BY created_at DESC LIMIT 500');res.json({orders:r.rows.map(o=>({...o,id:`FD-${String(o.id).padStart(6,'0')}`}))});}catch(e){console.error(e);res.status(500).json({error:'Could not load orders.'});}});
app.patch('/api/admin/orders/:id',requireAdmin,async(req,res)=>{const status=cleanString(req.body?.status,20);if(!['Pending','Processing','Completed','Cancelled'].includes(status))return res.status(400).json({error:'Invalid order status.'});const id=Number(String(req.params.id).replace(/^FD-0*/,''));try{const r=await pool.query('UPDATE orders SET status=$1 WHERE id=$2 RETURNING id,status',[status,id]);if(!r.rowCount)return res.status(404).json({error:'Order not found.'});res.json({ok:true});}catch(e){console.error(e);res.status(500).json({error:'Could not update order.'});}});
app.delete('/api/admin/orders/:id',requireAdmin,async(req,res)=>{const id=Number(String(req.params.id).replace(/^FD-0*/,''));try{const r=await pool.query('DELETE FROM orders WHERE id=$1',[id]);if(!r.rowCount)return res.status(404).json({error:'Order not found.'});res.json({ok:true});}catch(e){console.error(e);res.status(500).json({error:'Could not delete order.'});}});
app.put('/api/admin/settings',requireAdmin,async(req,res)=>{const b=req.body||{};const settings={name:cleanString(b.name,70)||defaultSettings.name,logo:cleanString(b.logo,5)||'F',tagline:cleanString(b.tagline,120),heroTitle:cleanString(b.heroTitle,140),heroText:cleanString(b.heroText,500),email:cleanString(b.email,200),whatsapp:cleanString(b.whatsapp,20).replace(/\D/g,''),phone:cleanString(b.phone,50),color:/^#[0-9a-fA-F]{6}$/.test(b.color)?b.color:defaultSettings.color,logoImageUrl:validHttpUrl(cleanString(b.logoImageUrl,1000)),portfolio:Array.isArray(b.portfolio)?b.portfolio.slice(0,20):[]};try{await pool.query('UPDATE site_settings SET settings=$1::jsonb,updated_at=NOW() WHERE id=1',[JSON.stringify(settings)]);res.json({ok:true,settings});}catch(e){console.error(e);res.status(500).json({error:'Could not save settings.'});}});

app.use(express.static(path.join(__dirname,'public'),{extensions:['html']}));
app.get('/admin',(req,res)=>res.sendFile(path.join(__dirname,'public','admin.html')));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));

initDb().then(()=>app.listen(port,'0.0.0.0',()=>console.log(`Faysal Design Co. server listening on ${port}`))).catch(err=>{console.error('Startup failed:',err.message);process.exit(1)});
process.on('SIGTERM',async()=>{await pool.end();process.exit(0)});
